const express = require('express');
const hbs = require('hbs');
const app = express();
const data = require('./publicapi.json');
const first300Records = data.slice(0, 300);

app.set('view engine', 'hbs');

app.get('/', (req, res) => {
  res.render('index', { data: first300Records });
});

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});