const axios = require('axios');
const fs = require('fs');

const apiUrl = 'https://api.publicapis.org/entries';

axios.get(apiUrl)
  .then(response => {
    const data = response.data.entries;
    const jsonData = JSON.stringify(data, null, 2);

    fs.writeFile('publicapi.json', jsonData, (err) => {
      if (err) {
        console.error('Error writing to file: ', err);
      } else {
        console.log('Data written to publicapi.json');
      }
    });
  })
  .catch(error => {
    console.error('Error fetching data from API: ', error);
  });
